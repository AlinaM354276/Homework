# labs_seminars
Team: 
1) Kartalieva Farida
2) Daniil Khrestianovskii
3) Maria Shmeleva
4) Mikheeva Alina
